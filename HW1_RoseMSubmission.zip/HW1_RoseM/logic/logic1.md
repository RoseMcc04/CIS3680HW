# Logic Development for HW 1

## User Input

- The user will input weight in pounds as a float var
- The user will input height in inches as a float var

## Metric Conversion

- kg = lbs / 2.205
- meters = inches * 0.0254

## BMI Formula

- BMI = kg / (meters ^ 2)
    - We will round this to two significant figures (0.00)

## Final Output

Your BMI is {bmi}. 